const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin'); 
var CompressionPlugin = require('compression-webpack-plugin');

let pathsToClean = [
  'public/dist/*',
]

let cleanOptions = {
  verbose:  true,
  dry:      false
}

module.exports = {
  entry: ['./src/index.js'],
  output: {
    filename: 'bundle-[hash:6].js',
    path: path.resolve(__dirname, 'public/dist')
  },
  module: {
      rules: [
          {
              test: /\.js?$/, 
              loader: 'babel-loader',
              exclude: /node_modules/
          },
          {
                test: /\.css$/,
                loader: ExtractTextPlugin.extract('css-loader', 'style-loader')
          },
          {
            test: /\.(woff|woff2|eot|ttf|otf)$/,
            loader: "file-loader"
          }
          ,
          {
            test: /\.(png|jpeg|jpg|gif|svg)$/,
            loader: "file-loader"
          }
      ]
  },
  devServer: {
      contentBase: path.resolve(__dirname, "public"),
      historyApiFallback: true,
      port: 3000,
      watchOptions: {
        // Delay the rebuild after the first change
        aggregateTimeout: 300,
  
        // Poll using interval (in ms, accepts boolean too)
        poll: 1000,
      },
  },
  plugins: [
    // Ignore node_modules so CPU usage with poll
    // watching drops significantly.
    new webpack.WatchIgnorePlugin([
      path.join(__dirname, "node_modules")
    ]),
    new CleanWebpackPlugin(pathsToClean, cleanOptions),
    new HtmlWebpackPlugin({
      hash: true,
      template: './index.html',
      filename: '../index.html',
      minify: {
        collapseWhitespace: true,
        collapseInlineTagWhitespace: true,
        removeComments: true,
        removeRedundantAttributes: true
      } //relative to root of the application
    }),
    new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
    new webpack.optimize.AggressiveMergingPlugin({
			minSizeReduce: 1.5
		}),
    new webpack.optimize.UglifyJsPlugin({
      include: /\.js?$/,
      sourceMap: true,
      parallel: 4,
      uglifyOptions: {
        output: {
          comments: false,
          beautify: false,
          warnings: false,
          screw_ie8: true,
          conditionals: true,
          unused: true,
          comparisons: true,
          sequences: true,
          dead_code: true,
          evaluate: true,
          if_return: true,
          join_vars: true
        },
        compress: {
          drop_console: true,
          warnings: false,
        }
      }
    }),
    new ExtractTextPlugin({
        filename:  (getPath) => {
          return getPath('[name].css').replace('css/js', 'css');
        },
        allChunks: true
    }),
    new CompressionPlugin({
      asset: "[path].gz[query]",
      algorithm: "gzip",
      test: /\.js$|\.css$|\.html$/,
      threshold: 10240,
      minRatio: 0.8
    })
  ],
};
