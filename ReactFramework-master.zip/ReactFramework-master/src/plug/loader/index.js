import React, { Component } from 'react';
import { Spin, Icon } from 'antd';

const antIcon = <Icon type="loading" style={{ fontSize: 24 }} spin />;

export default class Loader extends Component {
    render() {
        if(!this.props.loading) {
            return null;
        }
        return(
            <div className={this.props.isTable ? "position_absolute_loader" : "display_grid H_300px"}>
                <span className="margin_auto">
                    <Spin indicator={antIcon} />
                </span>
            </div>
        );
    }
}