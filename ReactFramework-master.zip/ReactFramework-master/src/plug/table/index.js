import { connect } from 'react-redux';
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import ReactTable from 'react-table';

class Table extends Component {

    constructor(props) {
        super(props);
        this.onPageChange = this.onPageChange.bind(this);
        this.state = {
            isLoading: false,
            sort: '',
            desc: 0,
            page: 1
        };
    }

    render() {
        return getList()
    }

    getList() {
        return (<ReactTable
            data={this.props.list}
            pages={this.props.totalPages}
            loading={this.state.loading}
            LoadingComponent={() => {return (<Loader loading={this.state.loading} isTable={true}/>)}}
            multiSort={false}
            page={this.state.page - 1}
            defaultPageSize={20}
            manual
            onFetchData={this.onFetchData}
            columns={this.props.columns}
            className="-highlight  editable_table"
            showPagination={true}
            showPageSizeOptions ={false}
            onPageChange={this.onPageChange}
            noDataText={this.state.loading ? '' : i18Get(this.props.emptyText, utils.getLanguage())}
            previousText={i18Get('Previous', utils.getLanguage())}
            nextText={i18Get('Next', utils.getLanguage())}
            pageText={i18Get('Page', utils.getLanguage())}
            ofText={i18Get('of', utils.getLanguage())}
            rowsText={i18Get('rows', utils.getLanguage())}
            getTrProps={function(state, rowInfo, column, instance) {
                return {
                    onClick: this.props.onClickWrapper ? this.props.onClickWrapper(rowInfo) : (e) => {},
                    style: this.props.style ? this.props.style : {}
                }
            }.bind(this)}
        />);
    }

    onFetchData(state) {
        var prevState = this.state;
        prevState.loading = true;
        if(state.sorted && state.sorted.length > 0) {
            prevState.sort = state.sorted[0].id;
            prevState.desc = state.sorted[0].desc ? 1 : 0;
        } else {
            prevState.sort = '';
            prevState.desc = 0;
        }
        this.setState(prevState);
        this.props.fetchDataFromServer(state, prevState);
    }

    onPageChange(pageIndex) {
        this.state.page = pageIndex + 1;
        if(document.getElementsByClassName('rt-tbody').length) {
            document.getElementsByClassName('rt-tbody')[0].scrollTop = 0;
        }
    }

}

Table.propTypes = {
    dispatch: PropTypes.func.isRequired,
};

export default withRouter(connect(store => ({
}))(Table));