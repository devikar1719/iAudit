import { message, Button } from 'antd';
import Config from '../config';

var language = 'en';

var getLanguage = () => {
    return language;
};

var setLanguage = (lang) => {
    language = lang;
};

var showSuccess = (msg) => {
    message.success(msg);
}

var showInfo = (msg) => {
    message.info(msg);
}

var showError = (msg) => {
    message.error(msg);
}

const regexEmail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

const regexPass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{5,}$/;

export default {
    regexPass, regexEmail, showSuccess, showInfo, showError, getLanguage, setLanguage,
};