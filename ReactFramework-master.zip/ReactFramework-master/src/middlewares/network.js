import axios from 'axios';
import utils from '../utils/utils';

export default {
  setupInterceptors: (store) => {
    axios.interceptors.response.use(function (response) {
        if(!response.data.status) {
            if(response.data.data && response.data.data.message) {
                utils.showError(response.data.data.message);
            } else {
                utils.showError(response.data.message);
            }
            return Promise.reject(response.data);
        } else if(response.data.status && response.data.message_code === 1) {
            if(response.config.method !== 'get' && response.data && response.data.message) {
                utils.showSuccess(response.data.message);
            }
            return response;
        } else if(response.data.message_code && response.data.message_code === 3) {
            response.data.data.forEach(function(validationFailure) {
                var message = validationFailure.msg;
                utils.showError(message);
            });
            return Promise.reject(response.data);
        } else if(response.data.message_code && response.data.message_code !== 1) {
            var message = (response.data ? response.data.message: response.message);
            utils.showError(message);
            return Promise.reject(response.data);
        } else {
            return response;
        }
    }, function (error) {
        return Promise.reject(error);
    });
  }
};