import Utils from '../utils/utils';
import Messages from '../actions/eventMessages'

export default function createLogger({ getState }) {
    return (next) => 
      (action) => {        
        if(action.type.endsWith('FULFILLED')) {
          const ACTION = action.type.replace('_FULFILLED', '');
          if(Messages[ACTION] && Messages[ACTION].SUCCESS) {
            Utils.showSuccess(Messages[ACTION].SUCCESS, Utils.getLanguage());
          }
        } else if(action.type.endsWith('REJECTED')) {
          const ACTION = action.type.replace('_REJECTED', '');
          if(Messages[ACTION] && Messages[ACTION].FAILED) {
            Utils.showError(Messages[ACTION].FAILED, Utils.getLanguage());
          }
        }
        return next(action);
    };
}