export default {
    dashboard: '/',
    not_found: '/404',
};
