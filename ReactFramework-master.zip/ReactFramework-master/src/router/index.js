import React from 'react';
import { HashRouter, Route, Switch } from 'react-router-dom';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { history } from '../store';
import MainSection from '../components/content/MainSection';
import locations from './locations';

class routes extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    componentWillMount() {
        this.props.history.listen(function (location) {
            this.props.location.pathname = location.pathname;
            this.props.location.search = location.search;
            this.forceUpdate();
        }.bind(this));
    }

    render() {

        return (
            <HashRouter history={history} basename="/">
                <Switch>
                    <Route path={ locations.dashboard } component={ MainSection } />
                </Switch>
            </HashRouter>
        );
    }
}

export default withRouter(connect(store => ({
    user: store.user,
    userRegister: store.userRegister,
}))(routes));
