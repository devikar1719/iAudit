import axios from 'axios';
import events from '../events';
import Utils from '../../utils/utils';
import Config from '../../messenger-config';

var TranslationFetch = () => ({
    type: events.TRANSLATION_FETCH,
    payload: axios.get(`${Config.apiRoot}/translations`),
});

var ResetLanguage = (language) => ({
    type: events.RESET_TRANSLATION_LANGUAGE,
    language,
});

var clearResetFlag = () => ({
    type: events.CLEAR_RESET_FLAG,
    payload: {},
});

export default {
    TranslationFetch,
    ResetLanguage,
    clearResetFlag,
}