import {
    createStore,
    applyMiddleware,
} from 'redux';
import promise from 'redux-promise-middleware';
import thunk from 'redux-thunk';
import logger from 'redux-logger';
import messageFilter from '../middlewares/messages';
import config from '../config';

import { routerMiddleware } from 'react-router-redux';
import createHistory from 'history/createBrowserHistory';
import reducers from '../reducers';

export const history = createHistory();

var store = null;
if(config.env && config.env === 'dev') {
    store = createStore(
        reducers,
        applyMiddleware(routerMiddleware(history), promise(), thunk, logger, messageFilter),
    );
} else {
    store = createStore(
        reducers,
        applyMiddleware(routerMiddleware(history), promise(), thunk, messageFilter),
    );
}
const Store = store;

export default Store;
