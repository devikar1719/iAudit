import React, { Component } from 'react'
import { Route, Switch } from 'react-router-dom';
import locations from '../../router/locations';
import LoginPage from '../user';

export default class MainSection extends Component {
 
  render() {
      return (
        <Switch>
          <Route path={locations.dashboard} component={LoginPage} />
        </Switch>
      )
    }
}