import { connect } from 'react-redux';
import React, { Component } from 'react';
import './user.css';
import PropTypes, { func } from 'prop-types';
import { withRouter } from 'react-router';
import ActionButton from '../../plug/action-button';
import events from '../../actions/events';

class LoginPage extends Component {
 
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
    }

    componentWillMount() {
        this.props.history.listen(location => {
            if (location.pathname !== this.props.location.pathname
            || location.search !== this.props.location.search) {
                this.props.location.pathname = location.pathname;
                this.props.location.search = location.search;
                this.forceUpdate();
            }
        });
    }

    onClick() {
        this.props.dispatch({
            type: events.ACTION_ONE,
            payload: {},
        });
    }

    render() {
        console.log(JSON.stringify(this.props.actions.actionOneInProgress));
        if(this.props.actions.actionOneInProgress) {
            this.props.dispatch({
                type: events.ACTION_ONE_CLEAR,
                payload: {},
            });
        }
        return (
            <div>
                <div>LOGIN</div>
                <ActionButton onClick={this.onClick} value='Submit' />
            </div>
        )
    }
}

LoginPage.propTypes = {
    actions: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
    history: PropTypes.object.isRequired,
};

export default withRouter(connect(store => ({ 
    actions: store.actions
}))(LoginPage));