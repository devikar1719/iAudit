import eventNames from '../../actions/events';
import Utils from '../../utils/utils';
import moment  from 'moment'
import configFile from '../../messenger-config';

const initialTranslationsState = {
    isTranslationFetchCompleted: false,
    language: 'en',
    isResetLanguageComplete: false,
    data: {},
};

export default function reducer(state = initialTranslationsState, action) {
    switch (action.type) {
    // TRANSLATION
    case eventNames.TRANSLATION_FETCH_PENDING:
        return {
            ...state,
            isTranslationFetchCompleted: 'PENDING',
        };
    case 'TRANSLATION_FETCH_FULFILLED':
        return {
            ...state,
            data: action.payload.data.data,
            isTranslationFetchCompleted: 'FULFILLED',
        };
    case eventNames.TRANSLATION_FETCH_REJECTED:
        return {
            ...state,
            isTranslationFetchCompleted: 'REJECTED',
        };
    case eventNames.RESET_TRANSLATION_LANGUAGE:
        Utils.setLanguage(action.language);
        return {
            ...state,
            language: action.language,
            isResetLanguageComplete: true,
        };
    case eventNames.CLEAR_RESET_FLAG:
        return{
            ...state,
            isResetLanguageComplete: false,
            isTranslationFetchCompleted: false,
        };
    default:
        return state;
    }
}
