import _ from 'lodash';
import eventNames from '../../actions/events';
import Config from '../../config';

const initialState = {
};

function getHeader(action) {
    return {
        authorization: [action.payload.data.token_type, action.payload.data.access_token].join(' '),
    };
}

export default function reducer(state = initialState, action) {
    switch (action.type) {
        default:
            return state;
    }
}