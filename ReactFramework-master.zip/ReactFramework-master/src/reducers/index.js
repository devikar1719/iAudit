import { combineReducers } from 'redux'
import user from './user'
import actions from './actions'

const rootReducer = combineReducers({
  user, actions
})

export default rootReducer
