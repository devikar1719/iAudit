export default {
    apiRoot : 'http://localhost:7777',
    env: 'dev',
};