import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import {} from 'react-fa';
import './index.css';
import { HashRouter } from 'react-router-dom';
import MyRouter from './router';
import store from './store';
import NetworkService from './middlewares/network';

NetworkService.setupInterceptors(store);

render(
  <Provider store={store}>
    <HashRouter>
      <MyRouter />
    </HashRouter>
  </Provider>,
  document.getElementById('root')
)
